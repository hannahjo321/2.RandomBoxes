$("quoteBtn").click(function(){
  var url = "http://quotes.rest/qod.json";
  $.getJSON(url, function(data){
    $('#header').append('<div id="quote"></div>' + data.quotes.quote + '<div id="author"></div>' + data.quotes.author)
  })
})

$("#getBtn").click(function(){
  var url = "https://contextualwebsearch-search-image-v1.p.mashape.com/api/Search/ImageSearchAPI" + $('#picInput').val();
  $.getJSON(url,function(data){
    $('#picContent').append('<div id="pic"></div><img src=" + data._type[0].value[0].url + "');
  });
});
